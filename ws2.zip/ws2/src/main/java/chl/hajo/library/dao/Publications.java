package chl.hajo.library.dao;

import javax.ejb.Stateless;


/**
 * Publication is a book and an author
 * @author hajo
 */
@Stateless
public class Publications {

 
}
